﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherOMatic.Net
{
    interface IDisplay
    {
        void Display();
    }
}
